package praxisblatt02.dataStructure;

import java.io.IOException;
import java.util.HashMap;
import java.util.Vector;

/**
 * A set of clauses.
 * 
 */
public class ClauseSet {
	/* Number of variables */
	private int varNum;

	/* Clauses of this set */
	private Vector<Clause> clauses;

	/* List of all variables */
	private HashMap<Integer, Variable> variables;

	/**
	 * Constructs a clause set from the given DIMACS file.
	 * 
	 * @param filePath
	 *            file path of the DIMACS file.
	 */
	public ClauseSet(String filePath) {
		//Parse the formula
		Integer[][] formula = null;
		try {
			formula = Parser.parseFile(filePath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(-1);
		}
		
		//set up class fields
		varNum = formula[0][0];
		clauses = new Vector<Clause>();
		variables = new HashMap<Integer, Variable>();
		
		for (int i = 1;i < formula.length;i++) {  //start with 1 because first entry contains statistical informations
			Vector<Integer> literals = new Vector<Integer>();
			Clause c = new Clause(new Vector<Integer>(), variables);
			for (int j = 0;j < formula[i].length;j++) {
				literals.add(formula[i][j]);
				
				//create entry in variables if variable is seen for the first time
				if (!variables.containsKey(Math.abs(formula[i][j]))) {
					variables.put(Math.abs(formula[i][j]), new Variable(Math.abs(formula[i][j])));
				} 
				
				//add the clause to the adjacency list
				variables.get(Math.abs(formula[i][j])).getAdjacencyList().add(c);
			}
			c.getLiterals().addAll(literals);
			c.setNumUnassigned(literals.size()); //no literals are assigned by now
			clauses.add(c);
		}
	}
	
	
	public static void main(String[] args) {
		//Test case 1
		ClauseSet set = new ClauseSet("formula01.cnf");
		System.out.println(set);
		set.unitPropagation();
		System.out.println(set);
		
		//Test case 2
		ClauseSet set2 = new ClauseSet("formula01.cnf");
		System.out.println(set2);
		set2.unitPropagation();
		System.out.println(set2);
	}
	

	/**
	 * Executes unit propagation and checks for the existence of an empty
	 * clause.
	 * 
	 * @return true, if an empty clause exists, otherwise false.
	 */
	public boolean unitPropagation() {
		while (!containsEmpty()) {  //repeat as long as there is no empty clause
			Clause nextU = nextUnit();
			if (nextU == null) {  //no unit clause left
				return false;
			}
			
			int lit = nextU.getUnassigned(variables);
			Variable v = variables.get(Math.abs(lit));
			
			//assign a value depending on the polarity of the var
			if (lit < 0) {  
				v.assign(false);
			} else {
				v.assign(true);
			}
		}
		return true;
	}

	/**
	 * Returns the next unit clause, if one exists.
	 * 
	 * @return next unit clause, if one exists, otherwise null
	 */
	private Clause nextUnit() {
		for (Clause c : clauses) {
			if (c.isUnit()) {  //unit found
				return c;
			}
		}
		return null;
	}

	/**
	 * Checks, if an empty clause exists.
	 * 
	 * @return true, if an empty clause exists, otherwise false.
	 */
	private boolean containsEmpty() {
		for (Clause c : clauses) {
			if (c.isEmpty()) {  //empty clause found
				return true;
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return clausesToString() + "\n\n" + varsToString();
	}

	/**
	 * Returns all clauses as string representation.
	 * 
	 * @return a string representation of all clauses.
	 */
	public String clausesToString() {
		String res = "";
		for (Clause clause : clauses)
			res += clause + "\n";
		return res;
	}

	/**
	 * Returns all variables as string representation.
	 * 
	 * @return a string representation of all variables.
	 */
	public String varsToString() {
		String res = "";
		for (int i = 1; i <= varNum; i++)
			res += "Variable " + i + ": " + variables.get(i) + "\n\n";
		return res;
	}
}